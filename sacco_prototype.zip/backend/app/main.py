from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from . import db, crud, schemas, models
from .db import SessionLocal, engine

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title='Sacco Accounting API')

def get_db():
    dbs = SessionLocal();
    try:
        yield dbs
    finally:
        dbs.close()

@app.post('/members', response_model=schemas.MemberRead)
def create_member_endpoint(member: schemas.MemberCreate, db: Session = Depends(get_db)):
    return crud.create_member(db, member)
